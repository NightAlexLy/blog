/* global hexo */

'use strict';

var assign = require('object-assign');

// when archive disabled pagination, per_page should be 0.
var per_page;

if (hexo.config.photo === 1) {
  per_page = 0;
} else if (typeof hexo.config.per_page === 'undefined') {
  per_page = 10;
} else {
  per_page = hexo.config.per_page;
}

hexo.config.photo_generator = assign({
  per_page: per_page,
  yearly: true,
  monthly: true,
  daily: false
}, hexo.config.photo_generator);

hexo.extend.generator.register('photo', require('./lib/generator'));
